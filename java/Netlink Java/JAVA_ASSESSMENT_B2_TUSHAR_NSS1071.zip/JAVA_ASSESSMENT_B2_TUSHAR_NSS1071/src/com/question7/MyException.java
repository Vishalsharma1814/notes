package com.question7;

public class MyException extends RuntimeException {
    public MyException(String s) {
        super();
    }
}
