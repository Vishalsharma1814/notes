package com.question4;

public class ListTooLargeException extends Throwable {
    public ListTooLargeException(String s) {

        super();

    }
}
